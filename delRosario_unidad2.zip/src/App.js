
import './App.css';
import Muestras from './Components/Muestras';

function App() {
  return (
    <Muestras />
  );
}

export default App;
